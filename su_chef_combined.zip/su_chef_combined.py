import json
import os
import string
from dotenv import load_dotenv
import azure.cognitiveservices.speech as speechsdk
import openai
from typing import Optional, Dict, List, Any
from database import RecipeDatabase
from datetime import datetime

class SuChefCombined:
    def __init__(self):
        print("Initializing Su-Chef Combined System...")
        # Load environment variables
        load_dotenv()
        print("Environment variables loaded")
        
        # Azure Speech Service configuration
        self.speech_key = os.getenv("SPEECH_KEY")
        self.speech_region = os.getenv("SPEECH_REGION", "westeurope")
        self.voice_name = os.getenv("VOICE_NAME", "en-US-JennyMultilingualNeural")
        self.language = os.getenv("LANGUAGE", "en-US")
        
        print(f"Speech key found: {bool(self.speech_key)}")
        print(f"Speech region: {self.speech_region}")
        
        # OpenAI configuration
        self.api_key = os.getenv("OPENAI_API_KEY")
        print(f"OpenAI key found: {bool(self.api_key)}")
        if not self.api_key:
            print("Error: OPENAI_API_KEY not found in environment variables!")
            return
            
        # Initialize database
        self.db = RecipeDatabase()
        print("Database initialized")
        
        # State management
        self.current_step = 0
        self.recipe_steps = []
        self.recipe_id = None
        self.user_id = None
        self.recipe_name = ""
        self.is_interrupted = False
        self.voice_mode = True  # Can be toggled for text-only mode
        
        # Initialize speech services if keys are available
        if self.speech_key:
            print("Initializing speech services...")
            self._init_speech_services()
            print("Speech services initialized")
        else:
            print("No speech key found - running in text-only mode")
            self.voice_mode = False
        
        print("Su-Chef Combined initialization complete!")
        
    def _init_speech_services(self):
        """Initialize Azure speech services."""
        try:
            self.speech_config = speechsdk.SpeechConfig(
                subscription=self.speech_key, 
                region=self.speech_region
            )
            self.speech_config.speech_synthesis_voice_name = self.voice_name
            self.speech_config.speech_recognition_language = self.language
            
            # Configure faster speech
            self.speech_config.set_speech_synthesis_output_format(
                speechsdk.SpeechSynthesisOutputFormat.Raw16Khz16BitMonoPcm
            )
            
            self.synthesizer = speechsdk.SpeechSynthesizer(speech_config=self.speech_config)
            self.recognizer = speechsdk.SpeechRecognizer(speech_config=self.speech_config)
        except Exception as e:
            print(f"Error initializing speech services: {e}")
            self.voice_mode = False
        
    def speak(self, text: str) -> bool:
        """Speak text with faster rate."""
        if not self.voice_mode or not text:
            return True
            
        ssml_text = f"""<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
            <voice name="{self.voice_name}">
                <prosody rate="+30.00%">
                    {text}
                </prosody>
            </voice>
        </speak>"""
        
        try:
            result = self.synthesizer.speak_ssml_async(ssml_text).get()
            return result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted
        except:
            return False
            
    def listen(self) -> Optional[str]:
        """Listen for user input or get text input."""
        if self.voice_mode:
            print("Speak now...")
            try:
                result = self.recognizer.recognize_once_async().get()
                if result.reason == speechsdk.ResultReason.RecognizedSpeech:
                    text = result.text.strip()
                    print(f"You said: {text}")
                    return text
            except:
                pass
            return None
        else:
            # Text-only mode
            return input("Your input: ").strip()

    def get_ai_response(self, question: str) -> Optional[str]:
        """Get dynamic AI response with smart command detection."""
        # First, let AI determine if this is a session command
        try:
            client = openai.OpenAI(api_key=self.api_key)
            command_check_messages = [
                {
                    "role": "system", 
                    "content": "You are analyzing user input to determine if it's a session command or cooking question. Respond with ONLY 'STOP' if the user wants to stop/quit/end the session, 'NEXT' if they want to proceed to next step, 'REPEAT' if they want to repeat current step, or 'QUESTION' if it's a cooking-related question."
                },
                {"role": "user", "content": f"User said: '{question}'"}
            ]
            
            command_response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=command_check_messages,
                temperature=0.1,
                max_tokens=10
            )
            
            ai_decision = command_response.choices[0].message.content.strip().upper()
            
            # Handle AI's decision
            if ai_decision == "STOP":
                self.speak("Ending the recipe guide.")
                self.is_interrupted = True
                return None
            elif ai_decision == "NEXT":
                self.current_step += 1
                if self.user_id and self.recipe_id:
                    self.db.update_step_progress(self.user_id, self.recipe_id, self.current_step)
                return None
            elif ai_decision == "REPEAT":
                self.speak_current_step(repeat_step=True)
                return None
                
        except Exception as e:
            print(f"AI Command Check Error: {str(e)}")
        
        # If it's a question, proceed with normal AI response
        if self.current_step < len(self.recipe_steps):
            current_step = self.recipe_steps[self.current_step]
            
            prompt = f"""Question about cooking step: '{current_step}'
            User asks: {question}
            
            Provide helpful, practical cooking advice in under 40 words."""
            
            try:
                messages = [
                    {
                        "role": "system", 
                        "content": "You are a helpful cooking expert. Keep responses under 40 words. Focus on practical, specific advice."
                    },
                    {"role": "user", "content": prompt}
                ]
                
                response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=messages,
                    temperature=0.7,
                    max_tokens=60
                )
                
                return response.choices[0].message.content
            except Exception as e:
                print(f"AI Error: {str(e)}")
                return None
        
        return "I can help you with cooking questions during recipe steps."

    def generate_recipe(self, meal_type, cooking_time, skill_level, dietary_restrictions=None, available_ingredients=None):
        """Generate a new recipe using OpenAI."""
        prompt = f"""Please suggest a {meal_type} recipe that:
- Takes {cooking_time} minutes or less to prepare
- Is suitable for a {skill_level} cook
"""
        
        if available_ingredients:
            prompt += f"- Uses some of these available ingredients: {', '.join(available_ingredients)}\n"
        
        if dietary_restrictions:
            prompt += f"\nMust be {dietary_restrictions}"
        
        prompt += """

Please provide the recipe in this format:
Recipe Name: [name]
Cooking Time: [time in minutes]
Ingredients:
- [ingredient 1]
- [ingredient 2]
Instructions:
1. [step 1]
2. [step 2]
"""
        
        try:
            client = openai.OpenAI(api_key=self.api_key)
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful cooking assistant that provides recipes."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=800
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating recipe: {str(e)}")
            return None

    def process_recipe_text(self, recipe_text, meal_type, cooking_time, skill_level, dietary_restrictions):
        """Process the recipe text into structured data."""
        lines = recipe_text.split('\n')
        recipe_data = {
            'name': '',
            'meal_type': meal_type,
            'cooking_time': int(cooking_time),
            'skill_level': skill_level,
            'dietary_restrictions': dietary_restrictions,
            'ingredients': [],
            'instructions': []
        }
        
        current_section = None
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if ':' in line:
                section = line.split(':', 1)[0].lower().strip()
                content = line.split(':', 1)[1].strip()
                
                if 'recipe name' in section:
                    recipe_data['name'] = content
                elif 'ingredients' in section:
                    current_section = 'ingredients'
                    if content:
                        recipe_data['ingredients'].append(content)
                elif 'instructions' in section:
                    current_section = 'instructions'
                    if content:
                        recipe_data['instructions'].append(content)
                continue
            
            if current_section == 'ingredients' and line:
                recipe_data['ingredients'].append(line.lstrip('- '))
            elif current_section == 'instructions' and line:
                if line[0].isdigit() or line.startswith('-') or line.startswith('•'):
                    recipe_data['instructions'].append(line.lstrip('0123456789.- •'))
        
        return recipe_data

    def load_recipe_from_db(self, recipe_id):
        """Load recipe from database for voice guidance."""
        recipe_data = self.db.get_recipe_details(recipe_id)
        if not recipe_data:
            return False
        
        recipe = recipe_data['recipe']
        steps = recipe_data['steps']
        
        self.recipe_id = recipe_id
        self.recipe_name = recipe[1]
        self.recipe_steps = [step[1] for step in steps]  # step[1] is step_text
        self.current_step = 0
        
        return True

    def load_recipe_from_file(self, filename: str = None) -> bool:
        """Load recipe steps from JSON file."""
        files_to_try = ["steps.json", "recipe.json"] if filename is None else [filename]
        
        for file_path in files_to_try:
            try:
                with open(file_path, 'r') as f:
                    recipe_data = json.load(f)
                    
                    # Handle steps.json format
                    if "steps" in recipe_data and isinstance(recipe_data["steps"], list):
                        if len(recipe_data["steps"]) > 0 and "text" in recipe_data["steps"][0]:
                            self.recipe_steps = [step["text"] for step in recipe_data["steps"]]
                            self.recipe_name = recipe_data.get("recipe_name", "Unknown Recipe")
                            return True
                        else:
                            self.recipe_steps = recipe_data["steps"]
                            self.recipe_name = recipe_data.get("name", "Unknown Recipe")
                            return True
                    
                    # Handle recipe.json format
                    elif "instructions" in recipe_data:
                        self.recipe_steps = recipe_data["instructions"]
                        self.recipe_name = recipe_data.get("name", "Unknown Recipe")
                        return True
                        
            except FileNotFoundError:
                continue
            except json.JSONDecodeError:
                print(f"Error: Invalid JSON format in {file_path}")
                continue
        
        return False
            
    def speak_current_step(self, repeat_step=True):
        """Speak the current recipe step."""
        if 0 <= self.current_step < len(self.recipe_steps):
            if repeat_step:
                step_text = f"Step {self.current_step + 1}: {self.recipe_steps[self.current_step]}"
                print(f"\n{step_text}")
                self.speak(step_text)
            print("\nSay 'help' for guidance, 'next' to continue, or ask any cooking question.")

    def run_voice_guidance(self):
        """Run the voice-guided cooking session."""
        if not self.recipe_steps:
            print("No recipe loaded for guidance.")
            return
            
        print(f"\nStarting voice guidance for: {self.recipe_name}")
        self.speak(f"Hi! I'm Su-Chef. I'll guide you through {self.recipe_name}. Say 'next' to continue, 'repeat' to hear again, or ask any cooking questions. Say 'stop' to end.")
        
        while not self.is_interrupted and self.current_step < len(self.recipe_steps):
            self.speak_current_step(repeat_step=True)
            
            while not self.is_interrupted:
                print("\nListening for your command or question...")
                user_input = self.listen()
                
                if not user_input:
                    continue
                    
                # Let AI handle all input
                response = self.get_ai_response(user_input)
                if response:
                    print("\nAssistant:", response)
                    self.speak(response)
                
                # Check if we should move to next step
                if self.current_step >= len(self.recipe_steps):
                    break
                    
        if not self.is_interrupted:
            print("\nRecipe completed!")
            self.speak("All done! Great job!")
            if self.user_id and self.recipe_id:
                self.db.mark_recipe_cooked(self.user_id, self.recipe_id, False)

    def main_menu(self):
        """Main interactive menu."""
        # Get user identification
        username = input("Please enter your username: ").strip()
        self.user_id = self.db.add_user(username)
        print(f"Welcome, {username}!")
        
        while True:
            print("\n" + "="*50)
            print("SU-CHEF - Your AI Cooking Assistant")
            print("="*50)
            print("1. Generate new recipe")
            print("2. Search saved recipes")
            print("3. Start voice guidance (current recipe)")
            print("4. Load recipe from file")
            print("5. Toggle voice mode")
            print("6. Exit")
            
            choice = input("\nChoose option (1-6): ").strip()
            
            if choice == "1":
                self._generate_recipe_flow()
            elif choice == "2":
                self._search_recipes_flow()
            elif choice == "3":
                if self.recipe_steps:
                    self.run_voice_guidance()
                else:
                    print("No recipe loaded. Please generate or search for a recipe first.")
            elif choice == "4":
                if self.load_recipe_from_file():
                    print(f"Recipe '{self.recipe_name}' loaded successfully!")
                else:
                    print("Failed to load recipe from file.")
            elif choice == "5":
                self.voice_mode = not self.voice_mode
                mode = "Voice" if self.voice_mode else "Text"
                print(f"Switched to {mode} mode")
            elif choice == "6":
                break
            else:
                print("Invalid choice. Please try again.")
        
        self.db.close()
        print("Thank you for using Su-Chef!")

    def _generate_recipe_flow(self):
        """Handle recipe generation flow."""
        print("\n--- Generate New Recipe ---")
        meal_type = input("Enter meal type (breakfast/lunch/dinner/snack): ").strip()
        cooking_time = input("Enter maximum cooking time in minutes: ").strip()
        skill_level = input("Enter skill level (beginner/intermediate/advanced): ").strip()
        
        # Dietary restrictions
        print("\nDietary restrictions:")
        print("1. Vegetarian  2. Vegan  3. Allergy  4. Kosher  5. Sugar-free  6. None")
        dietary_choice = input("Choose (1-6): ").strip()
        
        dietary_restrictions = None
        if dietary_choice == "3":
            dietary_restrictions = input("Specify allergy: ").strip()
        else:
            dietary_map = {"1": "vegetarian", "2": "vegan", "4": "kosher", "5": "sugar-free"}
            dietary_restrictions = dietary_map.get(dietary_choice)
        
        # Available ingredients
        ingredients_input = input("Available ingredients (comma-separated, or press Enter to skip): ").strip()
        available_ingredients = [i.strip() for i in ingredients_input.split(",")] if ingredients_input else None
        
        print("\nGenerating recipe...")
        recipe_text = self.generate_recipe(meal_type, cooking_time, skill_level, dietary_restrictions, available_ingredients)
        
        if recipe_text:
            print("\n" + "="*50)
            print("GENERATED RECIPE:")
            print("="*50)
            print(recipe_text)
            
            save_choice = input("\nSave this recipe? (y/n): ").strip().lower()
            if save_choice == 'y':
                recipe_data = self.process_recipe_text(recipe_text, meal_type, cooking_time, skill_level, dietary_restrictions)
                recipe_id = self.db.save_recipe(recipe_data, self.user_id)
                print(f"Recipe saved with ID: {recipe_id}")
                
                # Load for voice guidance
                if self.load_recipe_from_db(recipe_id):
                    print("Recipe loaded for voice guidance!")
        else:
            print("Failed to generate recipe.")

    def _search_recipes_flow(self):
        """Handle recipe search flow."""
        print("\n--- Search Recipes ---")
        print("1. Search by name")
        print("2. View cooked recipes")
        print("3. View liked recipes")
        
        choice = input("Choose option (1-3): ").strip()
        
        results = []
        if choice == "1":
            query = input("Enter recipe name to search: ").strip()
            results = self.db.search_recipes(query=query, search_type='name')
        elif choice == "2":
            results = self.db.search_recipes(user_id=self.user_id, search_type='cooked')
        elif choice == "3":
            results = self.db.search_recipes(user_id=self.user_id, search_type='liked')
        
        if not results:
            print("No recipes found.")
            return
        
        print("\nFound Recipes:")
        for i, recipe in enumerate(results, 1):
            print(f"{i}. {recipe[1]} ({recipe[3]} min, {recipe[4]})")
        
        if len(results) == 1:
            recipe_choice = "1"
        else:
            recipe_choice = input(f"\nSelect recipe (1-{len(results)}): ").strip()
        
        if recipe_choice.isdigit() and 1 <= int(recipe_choice) <= len(results):
            selected_recipe = results[int(recipe_choice)-1]
            recipe_id = selected_recipe[0]
            
            # Load recipe for voice guidance
            if self.load_recipe_from_db(recipe_id):
                print(f"Recipe '{self.recipe_name}' loaded for voice guidance!")
                
                start_guidance = input("Start voice guidance now? (y/n): ").strip().lower()
                if start_guidance == 'y':
                    self.run_voice_guidance()

def main():
    print("Starting Su-Chef Combined System...")
    try:
        chef = SuChefCombined()
        chef.main_menu()
    except Exception as e:
        print(f"Error starting Su-Chef: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 